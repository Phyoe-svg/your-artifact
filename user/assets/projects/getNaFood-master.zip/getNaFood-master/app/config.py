# config.py

DEBUG = True
SECRET_KEY = 'your_secret_key'
DATABASE_URI = 'your_database_uri'
JSON_AS_ASCII = False
SESSION_COOKIE_SAMESITE = None
DATABASE_URI = 'instance/data.db'
UPLOAD_FOLDER = "app/static/images"