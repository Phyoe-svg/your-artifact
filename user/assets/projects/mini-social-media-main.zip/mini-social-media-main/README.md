## mini-social-media
---
<p align="center">**Flask social app with login, sign_up, post and profile**</p>

---
alive at http://minisocialmedia.pythonanywhere.com/
there's no logout feature but if u want to logout from your current account request to `/auth/logout`


## To run locally
git clone https://github.com/PhyoeKyawThan/mini-social-media

cd mini-social-media

source venv/bin/activate

pip3 install -r requirements.txt

mkdir social/static/images && mkdir social/static/profiles

python3 main.py
